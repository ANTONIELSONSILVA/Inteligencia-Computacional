#ifndef LISTA_C_INCLUDED
#define LISTA_C_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

Elemento* lst_cria(void)
{
    return NULL;
}

Coluna* coluna_cria(void)
{
    return NULL;
}


Coluna* insereColuna(Coluna* col, int valor){

    Coluna* Aux=NULL;

        if(col == NULL){

            Coluna* novo =(Coluna*)malloc(sizeof(Coluna));
            novo->No = NULL;          // tipo Elemento
            novo->proxColuna = NULL;
            novo->info = valor;
            return novo;

        }else{

            Aux = col;

            while(Aux->proxColuna != NULL){
                Aux = Aux->proxColuna;
            }

            Coluna* novo =(Coluna*)malloc(sizeof(Coluna));
            novo->No = NULL;             // tipo Elemento
            novo->proxColuna = NULL;
            novo->info = valor;
            Aux->proxColuna = novo;
        }

        return Aux->proxColuna;


}




Elemento* insereValor(int val){

    Elemento* novo =(Elemento*)malloc(sizeof(Elemento));
    novo->info = val;
    novo->prox = NULL;
    return novo;

}


Elemento* lst_insere(Elemento* lst, int val)
{
    Elemento* Aux=NULL;

    if(lst == NULL){

        lst = insereValor(val);
        return lst;

    }else{

        Aux = lst;

        while(Aux->prox != NULL){
            Aux = Aux->prox;
        }

        Aux->prox = insereValor(val);

    }

    return lst;

}




void matrix_imprime(Coluna* col){

    Coluna* c = col;
    Elemento* Aux = c->No;


    for (c = col; c != NULL; c = c->proxColuna){
        printf("%i - ", c->info);
        for (Aux = c->No; Aux != NULL; Aux = Aux->prox){
            printf("%d -> ", Aux->info);
        }

        printf("NULL\n");

    }


}



Coluna* buscaCol(Coluna* col, int v)
{
    Coluna* c;
    for (c = col; c!=NULL; c = c->proxColuna)
    {
        if (c->info == v)
            return c;
    }
    return NULL;
}



void buscaGulosa(Coluna* col, int* Custos, int* visitados){

    int posicaoMenorRota=0;  // Armazena a menor rota para o pr�ximo vertice
    int menorRota;         // armazena a menor rota para fazer compara��es
    int i = col->info;

    Coluna* AuxCol = col;

    Elemento* Aux;

    // Enquanto o custo n�o for o menor
    while(Custos[i] != 0){
        // marco o vertice col->info como visitado
        visitados[col->info] = 1;
        Aux = col->No;


        menorRota = Custos[Aux->info];

        printf("\n%i \n", col->info); // primeiro v�rtice

        // enquato tenho Colunas, V�rtices abertos
        while(Aux != NULL){

            // fa�o a impress�o do Vertice j� visitado
            if (visitados[Aux->info] == 0)
            {
                printf("%i - ", Aux->info);
            }

            // estou percorrendo a lista ligada do N� e procurando o menor custo
            if (menorRota > Custos[Aux->info] && visitados[Aux->info] == 0){

                menorRota = Custos[Aux->info];
                posicaoMenorRota = Aux->info;

            }
            // vou para o pr�ximo la�o
            Aux = Aux->prox;
        }

        //printf("%i \n", posicaoMenorRota);

        col = buscaCol(AuxCol, posicaoMenorRota);
        i = posicaoMenorRota;

    }

}

















#endif // LISTA_C_INCLUDED
