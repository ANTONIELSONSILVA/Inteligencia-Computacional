#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

int main(){


    //Elemento* lst = lst_cria();
    Coluna* Col = coluna_cria();

    int custos[8]={0,24,15,22,12,7,7,0};
    int visitados[20];
    for (int i = 1; i <= 20; ++i)
        visitados[i] = 0;



    Col = insereColuna(Col, 1);
    Coluna* Aux = Col;
    Col->No = lst_insere(Col->No, 2);
    Col->No = lst_insere(Col->No, 3);
    Col->No = lst_insere(Col->No, 4);

    Col = insereColuna(Col, 2);
    Col->No = lst_insere(Col->No, 1);
    Col->No = lst_insere(Col->No, 4);
    Col->No = lst_insere(Col->No, 5);


    Col = insereColuna(Col, 3);
    Col->No = lst_insere(Col->No, 1);
    Col->No = lst_insere(Col->No, 6);

    Col = insereColuna(Col, 4);
    Col->No = lst_insere(Col->No, 1);
    Col->No = lst_insere(Col->No, 4);
    Col->No = lst_insere(Col->No, 5);
    Col->No = lst_insere(Col->No, 7);

    Col = insereColuna(Col, 5);
    Col->No = lst_insere(Col->No, 2);
    Col->No = lst_insere(Col->No, 4);
    Col->No = lst_insere(Col->No, 7);

    Col = insereColuna(Col, 6);
    Col->No = lst_insere(Col->No, 3);
    Col->No = lst_insere(Col->No, 7);

    Col = insereColuna(Col, 7);
    Col->No = lst_insere(Col->No, 4);
    Col->No = lst_insere(Col->No, 5);
    Col->No = lst_insere(Col->No, 6);



    matrix_imprime(Aux);
    printf("\n\nBusca Gulosa\n\n");

    buscaGulosa(Aux, custos, visitados);

    printf("\n");

    return 0;
}





