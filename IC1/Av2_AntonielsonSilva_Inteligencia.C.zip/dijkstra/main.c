#include <stdio.h>
#include <limits.h>
#define vertices 7


int menorDistancia(int distancia[], int abertos[])
{
    // Inicializa o valor m�nimo
    int infinito = INT_MAX;
    int menor;

    for (int i = 0; i < vertices; i++)

        if (abertos[i] == 0 && distancia[i] <= infinito){
            infinito = distancia[i], menor = i;
        }

    return menor;
}

// Uma fun��o utilit�ria para imprimir o array de dist�ncia constru�do
void printSResultado(int distancia[])
{
    printf("Vertices \t\t Distance ate aqui\n");
    for (int i = 0; i < vertices; i++)
        printf("%d \t\t\t %d\n", i, distancia[i]);
}


void dijkstra(int Grafo[vertices][vertices], int s)
{
    int distancia[vertices];        // vetor de dist�ncias
    int abertos[vertices];          // vetor de abertos

    // Inicializa todas as dist�ncias como infinito
    // todos os v�rtices abertos
    for (int i = 0; i < vertices; i++){
        distancia[i] = INT_MAX;
        abertos[i] = 0;
    }

    // v�rtice inicial
    // Ele � o menor
    distancia[s] = 0;

    // Encontra o caminho mais curto para todos os v�rtices
    for (int i = 0; i < vertices - 1; i++) {
         // Escolhe o v�rtice de dist�ncia m�nima do conjunto de v�rtices n�o
         // ainda processado. u � sempre igual a src na primeira itera��o.
        int menor = menorDistancia(distancia, abertos);


        abertos[menor] = 1;     // fecha o vertice

        // Atualiza a dist�ncia
        for (int i = 0; i < vertices; i++)

             // Atualiza distancia[v] somente se n�o estiver em abertos, existe uma aresta de
             // u para v, e o peso total do caminho de s para v passando por u �
             // menor que o valor atual de distancia[v]
            if (abertos[i] == 0 && Grafo[menor][i] && distancia[menor] != INT_MAX && distancia[menor] + Grafo[menor][i] < distancia[i]){
                // Atualizar a distancia i
                distancia[i] = distancia[menor] + Grafo[menor][i];
            }

    }


    printSResultado(distancia);
}


int main()
{
    int Grafo[vertices][vertices] = { { 0,9,5,13,0,0,0 },
                                      { 9,0,0,3,10,0,0 },
                                      { 5,0,0,0,0,12,0 },
                                      { 13,3,0,0,6,14,0 },
                                      { 0,10,0,6,0,0,7 },
                                      { 0,0,12,0,0,0,10 },
                                      { 0,0,0,0,7,10,0 } };

    dijkstra(Grafo, 0);

    return 0;
}
