# python-algoritmo-genetico
Genetic algorithm implementation written in Python.
Modeled to find the optimized time for intelligent traffic
lights and maximize the traffic flow crossing two streets with
random and unbalanced traffic streams.
The complete paper for this work can be found: http://www.sinaldetransito.com.br/artigos/algoritmo_genetico.pdf
